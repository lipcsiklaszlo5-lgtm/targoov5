{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "Vlk2fgXxPN9U6yvRc0pT14uRnJ9/DkwffR3S/VxB0Ts",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-04-14T16:22:51.310677769+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}