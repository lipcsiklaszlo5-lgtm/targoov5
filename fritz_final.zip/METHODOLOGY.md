# Methodology Report - Used Emission Factors

| Scope | Activity | EF Value | EF Unit | Source | Jurisdiction | GWP |
|-------|----------|----------|---------|--------|--------------|-----|
| SCOPE3 | Japan 39 | 39 | room per night | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | CodeTxt | 0 | eur | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | The provision of conversion factors is limited by the availability of data in different parts of the world If the hotel stay conversion factor for a certain country is not available in the current set users may continue to use factors from the last available set or visit https//wwwhotelfootprintsorg where more granular data is available by city and segment | 0 | nan | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | 153 | 153.10865 | million litres | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | 170 | 170.87549 | million litres | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | 191 | 191.30156 | million litres | Targoo Built-in Dictionary | EU | 1 |
