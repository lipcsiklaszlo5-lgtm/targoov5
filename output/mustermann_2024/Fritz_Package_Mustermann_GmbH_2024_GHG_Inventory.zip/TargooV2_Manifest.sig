{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "EE9GUVwnyjSm4cZ1tg0Ai0x+3VgI/T1fFtojCgIu8uA",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T20:01:48.829589004+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}