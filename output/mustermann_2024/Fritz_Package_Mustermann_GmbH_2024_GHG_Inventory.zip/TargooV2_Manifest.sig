{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "jg/vBnRkwZXgk8hSLBUPhrcoYn9xTpI+qNnaeOgXumA",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T21:20:56.329501109+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}