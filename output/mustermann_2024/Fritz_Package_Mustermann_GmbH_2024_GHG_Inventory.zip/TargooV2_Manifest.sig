{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "iGS6Bzlg495GTIT46iRTnEJbMgANymvwhZxXhfQSlhs",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T20:22:59.065067115+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}