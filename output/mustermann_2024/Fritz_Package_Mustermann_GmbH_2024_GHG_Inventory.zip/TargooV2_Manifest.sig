{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "ABJJ6wkpyi9GymlozHC+Bt4TAYIzpAgB2Fuic/Akt7U",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T20:41:09.354276864+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}