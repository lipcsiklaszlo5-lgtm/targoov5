{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "iWakoBuaUUNXRBoDonwGiwEdgm/dz/AbdHsaofQuZj4",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-10T19:39:45.356933719+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}