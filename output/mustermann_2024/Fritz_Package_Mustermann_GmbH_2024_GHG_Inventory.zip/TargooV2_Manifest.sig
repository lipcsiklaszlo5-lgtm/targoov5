{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "4SKtG0dQhykma4F1DpGUB9Yln4+TvqMuxgnDZtDbszE",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T21:49:18.248342647+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}