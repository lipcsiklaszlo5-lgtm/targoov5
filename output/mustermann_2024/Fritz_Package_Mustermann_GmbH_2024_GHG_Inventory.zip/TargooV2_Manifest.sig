{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "McRMi4lcEsUnKq4LvJyMKkSqT73v4P4p47EvJRZvcxY",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-10T20:04:56.916335915+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}