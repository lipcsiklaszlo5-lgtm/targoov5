{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "iuhIvggHT7niMXdcIJuQ7Fj0q+VlvoID2gIr8bqDm+w",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T20:53:10.808465088+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}