{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "B1xbRDYAqQcvKc8ykO8DeN/Q4JllSpNnBySgcFiytcw",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T20:43:34.538040961+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}