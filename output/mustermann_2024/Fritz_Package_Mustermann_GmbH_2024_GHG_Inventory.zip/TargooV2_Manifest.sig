{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "iIARIr8XdyF8ABUq02LNQg9Po+YHKxLBt5E48SfkWq8",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T20:55:54.046889097+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}