# Methodology Report - Used Emission Factors

| Scope | Activity | EF Value | EF Unit | Source | Jurisdiction | GWP |
|-------|----------|----------|---------|--------|--------------|-----|
| SCOPE1 | natural gas_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_EUR | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
