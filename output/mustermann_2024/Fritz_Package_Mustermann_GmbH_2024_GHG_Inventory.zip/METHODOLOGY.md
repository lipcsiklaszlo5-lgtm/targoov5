# Methodology Report - Used Emission Factors

| Scope | Activity | EF Value | EF Unit | Source | Jurisdiction | GWP |
|-------|----------|----------|---------|--------|--------------|-----|
| SCOPE1 | purchase1 | 0 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | cost4 | 0 | kWh | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | gaz2 | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | kwh3 | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | spend0 | 0 | currency | Targoo Built-in Dictionary | EU | 1 |
