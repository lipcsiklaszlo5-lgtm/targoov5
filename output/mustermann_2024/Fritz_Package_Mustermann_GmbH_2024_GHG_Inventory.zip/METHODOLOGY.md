# Methodology Report - Used Emission Factors

| Scope | Activity | EF Value | EF Unit | Source | Jurisdiction | GWP |
|-------|----------|----------|---------|--------|--------------|-----|
| SCOPE1 | natural gas_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | electricity_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | Diesel | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
