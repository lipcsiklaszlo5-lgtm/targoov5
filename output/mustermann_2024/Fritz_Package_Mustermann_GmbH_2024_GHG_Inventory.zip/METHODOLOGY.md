# Methodology Report - Used Emission Factors

| Scope | Activity | EF Value | EF Unit | Source | Jurisdiction | GWP |
|-------|----------|----------|---------|--------|--------------|-----|
| SCOPE1 | Erdgas | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | natural gas_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_m3 | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | stromverbrauch | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | electricity consumption_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | áramfogyasztás | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | Diesel | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_km | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | repülő_km | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_EUR | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_USD | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_HUF | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Metals 3815 | 3815.78473 | tonnes | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Concrete 118 | 118.75127 | tonnes | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | hulladék_kWh | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | Kältemittel | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_kg | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | upstream_transport_km | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
