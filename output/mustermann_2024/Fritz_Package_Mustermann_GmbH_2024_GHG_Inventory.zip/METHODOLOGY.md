# Methodology Report - Used Emission Factors

| Scope | Activity | EF Value | EF Unit | Source | Jurisdiction | GWP |
|-------|----------|----------|---------|--------|--------------|-----|
| SCOPE1 | SAP_NATURAL_GAS | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | Diesel | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | natural gas_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | Kältemittel | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_kg | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 25200 |
| SCOPE3 | purchased_goods_EUR | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_kg | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | Strom | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | tkm_kWh | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_tonne | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Concrete 118 | 118.75127 | tonnes | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_km | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Tyres 33355719 | 3335.5719 | tonnes | Targoo Built-in Dictionary | EU | 1 |
