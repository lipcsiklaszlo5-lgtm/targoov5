# Methodology Report - Used Emission Factors

| Scope | Activity | EF Value | EF Unit | Source | Jurisdiction | GWP |
|-------|----------|----------|---------|--------|--------------|-----|
| SCOPE1 | SAP_NATURAL_GAS | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | Diesel | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | natural gas_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | Kältemittel | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_kg | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 25200 |
| SCOPE3 | purchased_goods_EUR | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_kg | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Cat2_Maschinen_Investition | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | Strom | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Cat4_Eingehende_Transporte | 0.00033 | tkm | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Cat5_Abfall_Deponierung | 0.00033 | tonne | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Cat5_Recycling | 0.00033 | tonne | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | purchased_goods_km | 0.00033 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Cat6_Hotelnächte | 0.00033 | night | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Cat8_Gemietete_Lager | 0.00033 | m2 | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Cat9_Ausgehende_Transporte | 0.00033 | tkm | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Tyres 33355719 | 3335.5719 | tonnes | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Cat13_Downstream_Leasing | 0.00033 | m2 | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Cat14_Franchise_Emissionen | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Cat15_Investitionen_Portfolio | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
