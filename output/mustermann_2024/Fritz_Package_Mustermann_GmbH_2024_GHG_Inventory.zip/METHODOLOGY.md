# Methodology Report - Used Emission Factors

| Scope | Activity | EF Value | EF Unit | Source | Jurisdiction | GWP |
|-------|----------|----------|---------|--------|--------------|-----|
| SCOPE3 | Bond_Investment_EUR | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | Gasoline_Liter | 0.1837 | liter | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | District_Heat_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Equity_Investment_EUR | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Real_Estate_Investment_EUR | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | Refrigerant_R410A_kg | 0.1837 | kg | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Taxi_Travel_km | 0.00033 | km | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Electronics_Parts_EUR | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Train_Travel_km | 0.00033 | km | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Plastic_Resin_EUR | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Road_Freight_tkm | 0.00033 | tkm | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Sea_Freight_tkm | 0.00033 | tkm | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Air_Cargo_tkm | 0.00033 | tkm | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Flight_Travel_km | 0.00033 | km | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | Diesel | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | green power_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Waste_Landfill_tonnes | 0.00033 | tonne | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Waste_Recycled_tonnes | 0.00033 | tonne | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | electricity_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | Steel_Purchase_EUR | 0.00033 | EUR | Targoo Built-in Dictionary | EU | 1 |
| SCOPE1 | natural gas_kWh | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
