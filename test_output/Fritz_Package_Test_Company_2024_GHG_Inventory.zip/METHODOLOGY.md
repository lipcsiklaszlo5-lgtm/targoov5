# Methodology Report - Used Emission Factors

| Scope | Activity | EF Value | EF Unit | Source | Jurisdiction | GWP |
|-------|----------|----------|---------|--------|--------------|-----|
