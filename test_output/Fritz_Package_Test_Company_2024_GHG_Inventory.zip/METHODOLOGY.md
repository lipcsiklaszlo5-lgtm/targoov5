# Methodology Report - Used Emission Factors

| Scope | Activity | EF Value | EF Unit | Source | Jurisdiction | GWP |
|-------|----------|----------|---------|--------|--------------|-----|
| SCOPE1 | power2300 | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
| SCOPE3 | WAREN_EINGANG8000 | 0.00033 | currency | Targoo Built-in Dictionary | EU | 1 |
| Scope2Lb | kwh3 | 0.1837 | kWh | Targoo Built-in Dictionary | EU | 1 |
