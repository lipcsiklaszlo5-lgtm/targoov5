{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "qCTEPvTfQ6D22V7JMQxgfvLf+jPWwGXMBFl8VsyipNg",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T21:01:30.982132494+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}