{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "kp6wMBIAKhEMGwK6fjVy/RVC+4yMv8hyE22pOOtFUvg",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T20:03:43.946636126+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}