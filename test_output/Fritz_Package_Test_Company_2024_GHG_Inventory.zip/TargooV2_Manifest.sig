{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "NE5QHU/5VoWdEeMAgmAbQeiR1c4GIGYP/cOAu5q/gdk",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T20:27:16.807321060+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}