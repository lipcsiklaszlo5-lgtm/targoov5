{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "tB6LZbVayiyFjucefI6fU+k53TfVeeEKSsKc7Py16aA",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T00:01:21.504903970+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}