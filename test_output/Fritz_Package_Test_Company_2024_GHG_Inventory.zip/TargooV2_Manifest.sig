{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "QUVWdwl8qVETKAWCUADuS5UAWWtDrDEZi4gMwmtCCVg",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-10T19:02:48.702211479+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}