{
  "protected": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImNyaXQiOlsiZXhwIl19",
  "payload": "Ar20K09UU+5ZM7HLW+ssbg4oViMbcMxlggVmlZUbO94",
  "signature": "HMAC_SHA256_STUB_SIGNATURE_TARG_V2_2026",
  "timestamp": "2026-05-11T20:07:54.115242013+00:00",
  "certificate": "TargooV2_SelfSigned_v1"
}